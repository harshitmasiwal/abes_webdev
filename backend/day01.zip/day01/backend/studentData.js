const students = [
  {
    id: 1,
    name: "Aarav Sharma",
    age: 20,
    branch: "Computer Science",
    email: "aarav.sharma@example.com",
    year: "2nd",
    cgpa: 8.5
  },
  {
    id: 2,
    name: "Priya Verma",
    age: 19,
    branch: "Information Technology",
    email: "priya.verma@example.com",
    year: "1st",
    cgpa: 8.9
  },
  {
    id: 3,
    name: "Rohan Gupta",
    age: 21,
    branch: "Electronics",
    email: "rohan.gupta@example.com",
    year: "3rd",
    cgpa: 7.8
  },
  {
    id: 4,
    name: "Sneha Singh",
    age: 20,
    branch: "Mechanical",
    email: "sneha.singh@example.com",
    year: "2nd",
    cgpa: 8.2
  },
  {
    id: 5,
    name: "Vikram Yadav",
    age: 22,
    branch: "Civil",
    email: "vikram.yadav@example.com",
    year: "4th",
    cgpa: 7.3
  }
];


module.exports = students ; 